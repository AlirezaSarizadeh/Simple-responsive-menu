<!--منو حالت گوشی-->
<nav class="nav panel-menu" role="navigation" id="panel-menu">
  <span class="closePanel close-menu"><i class="fa fa-times"></i></span>
  <div class="row header-menu">
    <div class="col-12 p-0">
      <div class="btn-menu">
        <a title="related title" href="">
          <img
            alt="related alt"
            title="related title"
            src="https://younesgold.com/vade-negar/images/logo.svg"
            class="img-fluid"
          />
        </a>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-12 p-0">
      <ul>
        <li class="main-menu">
          <a title="related title" href="">صفحه اصلی</a>
        </li>
        <li class="main-menu">
          <span class="openSubPanel">
            خدمات
            <span class="arow-menu"><i class="fa fa-arrow-right"></i></span>
          </span>
          <ul class="subPanel">
            <li class="close-li">
              <span class="closeSubPanel">
                <i class="fa fa-arrow-left mx-2"></i> بازگشت
              </span>
            </li>
            <li class="main-menu">
              <span class="openSubPanel">
                زیرمنو
                <span class="arow-menu"><i class="fa fa-arrow-right"></i></span>
              </span>
              <ul class="subPanel">
                <li class="close-li">
                  <span class="closeSubPanel">
                    <i class="fa fa-arrow-left mx-2"></i> بازگشت
                  </span>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
              </ul>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
          </ul>
        </li>
        <li class="main-menu">
          <span class="openSubPanel">
            پروژه ها
            <span class="arow-menu"><i class="fa fa-arrow-right"></i></span>
          </span>
          <ul class="subPanel">
            <li class="close-li">
              <span class="closeSubPanel">
                <i class="fa fa-arrow-left mx-2"></i> بازگشت
              </span>
            </li>
            <li class="main-menu">
              <span class="openSubPanel">
                زیرمنو
                <span class="arow-menu"><i class="fa fa-arrow-right"></i></span>
              </span>
              <ul class="subPanel">
                <li class="close-li">
                  <span class="closeSubPanel">
                    <i class="fa fa-arrow-left mx-2"></i> بازگشت
                  </span>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
              </ul>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
          </ul>
        </li>
        <li class="main-menu">
          <span class="openSubPanel">
            محصولات
            <span class="arow-menu"><i class="fa fa-arrow-right"></i></span>
          </span>
          <ul class="subPanel">
            <li class="close-li">
              <span class="closeSubPanel">
                <i class="fa fa-arrow-left mx-2"></i> بازگشت
              </span>
            </li>
            <li class="main-menu">
              <span class="openSubPanel">
                زیرمنو
                <span class="arow-menu"><i class="fa fa-arrow-right"></i></span>
              </span>
              <ul class="subPanel">
                <li class="close-li">
                  <span class="closeSubPanel">
                    <i class="fa fa-arrow-left mx-2"></i> بازگشت
                  </span>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
                <li class="main-menu">
                  <a title="related title" href=""> زیر منو </a>
                </li>
              </ul>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
            <li class="main-menu">
              <a title="related title" href=""> زیر منو </a>
            </li>
          </ul>
        </li>
        <li class="main-menu">
          <a title="related title" href="#">گالری تصاویر </a>
        </li>
        <li class="main-menu"><a title="related title" href="#"> بلاگ </a></li>
        <li class="main-menu">
          <a title="related title" href="#">درباره ما</a>
        </li>
        <li class="main-menu">
          <a title="related title" href="#">تماس با ما</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!--هدر-->

<header class="container-fluid c-header js-header p-0">
  <div class="row top-header align-items-center pt-md-0">
    <div class="col-xl-9 col-lg-9 col-md-9 col-5 p-0">
      <div class="row align-items-center row-top-header">
        <div class="col-12 d-xl-none d-lg-none text-md-end">
          <a title="related title" href="" class="">
            <img
              alt="related alt"
              title="related title"
              src="https://younesgold.com/vade-negar/images/logo.svg"
              class="img-fluid logo-img"
            />
          </a>
        </div>
        <div class="col-lg-12 col-md-2 d-none d-lg-block p-0">
          <div class="cssmenu" id="cssmenu1">
            <ul class="text-start">
              <li class=""><a title="related title" href="">صفحه اصلی</a></li>
              <li class="has-sub">
                <a title="related title" href="">
                  خدمات
                  <i class="fa fa-chevron-down"></i>
                </a>

                <!--childs-->
                <ul>
                  <li class="has-sub">
                    <a title="related title" href=""> سردسته </a>
                    <ul>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                    </ul>
                  </li>

                  <li><a title="related title" href="">زیر منو تستی</a></li>
                  <li><a title="related title" href="">زیر منو تستی</a></li>
                  <li><a title="related title" href="">زیر منو تستی</a></li>
                </ul>
              </li>
              <li class="has-sub">
                <a title="related title" href="">
                  پروژه ها
                  <i class="fa fa-chevron-down"></i>
                </a>

                <!--childs-->
                <ul>
                  <li class="has-sub">
                    <a title="related title" href=""> سردسته </a>
                    <ul>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                    </ul>
                  </li>

                  <li><a title="related title" href="">زیر منو تستی</a></li>
                  <li><a title="related title" href="">زیر منو تستی</a></li>
                  <li><a title="related title" href="">زیر منو تستی</a></li>
                </ul>
              </li>
              <li class="has-sub">
                <a title="related title" href="">
                  محصولات
                  <i class="fa fa-chevron-down"></i>
                </a>

                <!--childs-->
                <ul>
                  <li class="has-sub">
                    <a title="related title" href=""> سردسته </a>
                    <ul>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                      <li><a title="related title" href="">زیر منو تستی</a></li>
                    </ul>
                  </li>

                  <li><a title="related title" href="">زیر منو تستی</a></li>
                  <li><a title="related title" href="">زیر منو تستی</a></li>
                  <li><a title="related title" href="">زیر منو تستی</a></li>
                </ul>
              </li>
              <li class="">
                <a title="related title" href="">گالری تصاویر </a>
              </li>
              <li class=""><a title="related title" href="">بلاگ </a></li>
              <li class=""><a title="related title" href="">درباره ما </a></li>
              <li class="search-ico">
                <span class="mx-3 d-md-block d-none"> | </span>
              </li>
              <li class="search-ico">
                <span class="search-icon">
                  <img
                    src="{{ asset('images/search-icon.png') }}"
                    width="24px"
                  />
                </span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="col-xl-3 col-lg-3 col-md-3 col-7 ps-md-0 right-toolbar-col">
      <!--نمایش گوشی-->
      <div class="col-12 col-md-10 d-xl-none d-lg-none text-start">
        <ul class="toolbar-mob d-flex align-items-center gap-3">
          <li class="search-ico">
            <span class="search-icon">
              <img src="{{ asset('images/search-icon.png') }}" width="24px" />
            </span>
          </li>
          <li class="menuTrigger">
            <span><i class="fa fa-bars"></i></span>
          </li>
        </ul>
      </div>
      <a
        title="related title"
        href=""
        class="d-inline-block d-none d-lg-block text-end"
      >
        <img
          alt="related alt"
          title="related title"
          src="https://younesgold.com/vade-negar/images/logo.svg"
          class="img-fluid"
        />
      </a>
    </div>
  </div>
</header>

<!--باکس جستجو-->
<div class="box-search">
  <div class="search-inner">
    <form action="" method="post" class="search-form">
      <div class="frm">
        <input
          type="text"
          placeholder="جستجو کنید..."
          class="input-search"
          name=""
        />
        <button class="btn-serch icon-theme">
          <img src="{{ asset('images/search-icon.png') }}" width="24px" />
        </button>
      </div>
    </form>
    <div class="btSearchInnerClose icon-theme">
      <!--<i class="fal fa-times-circle"></i>-->
      <img src="{{ asset('images/close-icon.png') }}" />
    </div>
  </div>
</div>
