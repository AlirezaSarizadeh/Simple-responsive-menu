$( document ).ready(function() {
// new menu scripts
$(".menuTrigger").click(function () {
  $(".panel-menu").toggleClass("isOpen");
});

$(".openSubPanel").click(function () {
  $(this).next(".subPanel").addClass("isOpen");
});

$(".closeSubPanel").click(function () {
  $(this).closest(".subPanel").removeClass("isOpen");
});

$("#panel-menu").on("click", function (e) {
  var target = $(e.target);
  if (
    target.attr("id") == "menu-toggle" ||
    target.parents("#panel-menu").length > 0 ||
    target.parents(".panel-menu").length > 0
  ) {
    console.log(
      "id: " +
        target.attr("id") +
        "contains: " +
        $.contains(target, $(".panel-menu"))
    );
  } else {
    if ($(".panel-menu").hasClass("isOpen"))
      $(".panel-menu").removeClass("isOpen");
    $(".subPanel").removeClass("isOpen");
  }
});

$(".closePanel").click(function () {
  $(".panel-menu").removeClass("isOpen");
  $(".subPanel").removeClass("isOpen");
});

if (matchMedia("only screen and (min-width: 768px)").matches) {
  $(document).ready(function () {
    $(window).scroll(function () {
      if ($(window).scrollTop() > 50) {
        $(".c-header.js-header").addClass("fixed");
      } else {
        $(".c-header.js-header").removeClass("fixed");
      }
    });
  });
}

$(".search-ico").click(function () {
  $(".box-search").toggleClass("SearchOpen ");
});
$(".btSearchInnerClose").click(function () {
  $(".box-search").removeClass("SearchOpen ");
});
});
